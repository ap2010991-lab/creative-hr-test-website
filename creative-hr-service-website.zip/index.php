<?php $title = 'Recruitment & Resume Writing in Vapi'; require __DIR__ . '/includes/header.php'; ?>
<section class="hero">
    <div class="hero-copy">
        <p class="eyebrow">Founded in 2014 · Recruitment and resume writing in Vapi</p>
        <h1>Creative HR Service</h1>
        <p class="lead"><?= h($site['tagline']) ?></p>
        <p><?= h(page_content('home_intro')) ?></p>
        <div class="hero-actions">
            <a class="btn primary" href="#resume-upload">Upload Resume</a>
            <a class="btn secondary" href="/contact.php">Hire Talent</a>
        </div>
    </div>
    <form class="resume-panel" id="resume-upload" action="/submit-resume.php" method="post" enctype="multipart/form-data">
        <h2>Upload Your Resume</h2>
        <p>Share your details for future job updates and suitable opportunities.</p>
        <div class="form-grid">
            <input name="name" placeholder="Full name" required>
            <input name="phone" placeholder="Mobile number" required>
            <input name="email" type="email" placeholder="Email address">
            <input name="city" placeholder="Current city">
            <input name="experience" placeholder="Experience">
            <input name="role" placeholder="Preferred job role">
        </div>
        <input class="file-input" name="resume" type="file" accept=".pdf,.doc,.docx" required>
        <button class="btn primary full" type="submit">Submit Resume</button>
    </form>
</section>

<section class="stats">
    <div><strong>2014</strong><span>Founded</span></div>
    <div><strong>12+</strong><span>Years Founder Experience</span></div>
    <div><strong>480+</strong><span>Industry Network Signals</span></div>
    <div><strong>2</strong><span>Core HR Services</span></div>
</section>

<section class="split">
    <div>
        <p class="eyebrow">For employers</p>
        <h2>Find dependable candidates faster.</h2>
        <p>From office roles to factory teams, technical profiles, sales, accounts, admin, operators, engineers, and managers, we help companies shortlist practical candidates for Vapi and nearby areas.</p>
        <a class="text-link" href="/recruitment.php">Explore recruitment</a>
    </div>
    <img src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1200&q=80" alt="Professional recruitment discussion">
</section>

<section class="split reverse">
    <img src="https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&w=1200&q=80" alt="Resume writing workspace">
    <div>
        <p class="eyebrow">For job seekers</p>
        <h2>Present your profile with confidence.</h2>
        <p>We create and improve resumes for freshers and experienced candidates, including professional CV writing, formatting, cover letters, and LinkedIn profile guidance.</p>
        <a class="text-link" href="/resume-writing.php">Explore resume writing</a>
    </div>
</section>

<section class="content-section">
    <p class="eyebrow">Why choose us</p>
    <h2>Built for practical hiring and career support.</h2>
    <div class="feature-grid">
        <article><h3>Fast Response</h3><p>We keep communication clear for candidates and employers so every enquiry moves forward without confusion.</p></article>
        <article><h3>Vapi Focus</h3><p>Our service is designed for Vapi, Daman, Chala, GIDC, Valsad, Silvassa, and nearby industrial and business areas.</p></article>
        <article><h3>Two Clear Services</h3><p>We focus on recruitment and resume writing, which keeps our process simple, direct, and easy for clients to understand.</p></article>
    </div>
</section>

<section class="content-section gradient-section">
    <p class="eyebrow">Industry reach</p>
    <h2>Recruitment insight for South Gujarat industries.</h2>
    <div class="feature-grid">
        <article><h3>Pharma & Chemical</h3><p>Awareness of 180+ pharma and chemical companies in South Gujarat from the company profile.</p></article>
        <article><h3>Plastics & Packaging</h3><p>Serving hiring categories connected to 250+ plastics product manufacturing companies in Daman and DNH.</p></article>
        <article><h3>Textile & Garment</h3><p>Understanding of large textile and garment manufacturing environments across Gujarat and Maharashtra.</p></article>
    </div>
</section>

<section class="content-section light-section">
    <p class="eyebrow">How it works</p>
    <h2>Simple steps for candidates and employers.</h2>
    <div class="process-grid">
        <div><span>01</span><h3>Share Requirement</h3><p>Employers share hiring needs, or candidates upload their resume with career preferences.</p></div>
        <div><span>02</span><h3>Profile Review</h3><p>We understand role fit, experience, skills, location preference, and expected job category.</p></div>
        <div><span>03</span><h3>Shortlisting</h3><p>Suitable candidates or opportunities are matched based on practical requirements.</p></div>
        <div><span>04</span><h3>Follow Up</h3><p>Our team coordinates updates, interview support, and next communication steps.</p></div>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
